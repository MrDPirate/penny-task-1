const baseConfig = require('../../eslint.base.config.cjs');


module.exports = [...baseConfig, ...baseConfig, ...baseConfig];
