export class ResetPasswordDto {
    token: string;
    newPassword: string;
  }
  